from django.contrib import admin
from .models import VideoGame

# Register your models here.
# password admin/admin

admin.site.register(VideoGame)
