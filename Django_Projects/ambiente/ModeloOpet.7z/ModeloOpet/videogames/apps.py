from django.apps import AppConfig


class VideogamesConfig(AppConfig):
    name = 'videogames'
